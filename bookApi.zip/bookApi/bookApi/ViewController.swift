//
//  ViewController.swift
//  bookApi
//
//  Created by okokok on 26.02.2024.
//

import UIKit
import WebKit
import SVProgressHUD

class ViewController: UIViewController, WKNavigationDelegate {

    @IBOutlet weak var webview: WKWebView!
    
    var book = BooksApi()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        webview.navigationDelegate = self
        
        // Choosing the first author's name
                if let firstAuthor = book.author_name.first {
                    // Constructing URL from the first author's name
                    if let url = URL(string: firstAuthor) {
                        let urlRequest = URLRequest(url: url)
                        webview.load(urlRequest)
                    } else {
                        print("Invalid URL")
                    }
                } else {
                    print("No author name available")
                }
            }
    }
    
    // MARK: - WKWebView delegate
    
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!){
        SVProgressHUD.show()
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        SVProgressHUD.dismiss()
    }
    
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        SVProgressHUD.dismiss()
    }
   
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!,withError error: Error) {
        SVProgressHUD.dismiss()
    }




