//
//  BooksApi.swift
//  bookApi
//
//  Created by okokok on 26.02.2024.
//

import Foundation
import SwiftyJSON

struct BooksApi {
    var title = " "
    var ebook_access = " "
    var first_publish_year = 0
    var edition_count = 0
    var author_name: [String] = []
    
    init ( ){
        
    }
    
    init(json: JSON) {
        if let item = json["title"].string {
            title = item
        }
        if let item = json["ebook_access"].string {
            ebook_access = item
        }
        if let item = json["first_publish_year"].int {
            first_publish_year = item
        }
        if let item = json["edition_count"].int {
            edition_count = item
        }
        if let itemArray = json["author_name"].array {
            for item in itemArray {
                if let author = item.string {
                    author_name.append(author)
                    
                }
            }
            
        }
    }
}
