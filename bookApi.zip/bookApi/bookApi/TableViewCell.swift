//
//  TableViewCell.swift
//  bookApi
//
//  Created by okokok on 26.02.2024.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var subtitleLabel: UILabel!
    @IBOutlet weak var firstPublishYearLabel: UILabel!
    @IBOutlet weak var editionCountLabel: UILabel!
    @IBOutlet weak var lendingIdentifierLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setData(book: BooksApi){
        titleLabel.text = book.title
        subtitleLabel.text = book.ebook_access
        firstPublishYearLabel.text = "\(book.first_publish_year)"
        editionCountLabel.text = "\(book.edition_count)"
        
        let authorsString = book.author_name.joined(separator: ", ")
            lendingIdentifierLabel.text = authorsString
    }

}
