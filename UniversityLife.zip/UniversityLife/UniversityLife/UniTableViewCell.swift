//
//  UniTableViewCell.swift
//  UniversityLife
//
//  Created by okokok on 15.02.2024.
//

import UIKit
import SDWebImage

class UniTableViewCell: UITableViewCell {
    
    @IBOutlet weak var pictureImageView: UIImageView!
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var locationLabel: UILabel!
    
    @IBOutlet weak var logoImageView: UIImageView!
    
    @IBOutlet weak var infoLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    func setData(university: UniversityLife){
        nameLabel.text = university.name
        locationLabel.text = university.location
        infoLabel.text = university.info
        
        
        pictureImageView.sd_setImage(with: URL(string: university.picture), completed: nil)
        logoImageView.sd_setImage(with: URL(string: university.logo), completed: nil)
        
    }
}
