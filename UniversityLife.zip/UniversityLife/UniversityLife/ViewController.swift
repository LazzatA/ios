//
//  ViewController.swift
//  UniversityLife
//
//  Created by okokok on 15.02.2024.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

