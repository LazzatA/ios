//
//  UniversityLife.swift
//  UniversityLife
//
//  Created by okokok on 15.02.2024.
//

import Foundation
import SwiftyJSON

struct UniversityLife {
    var name = " "
    var location = " "
    var info = " "
    var picture = " "
    var logo = " "
    
    init(json: JSON){
        if let item = json["name"].string{
            name = item
        }
        if let item = json["location"].string{
            location = item
        }
        if let item = json["info"].string{
            info = item
        }
        if let item = json["picture"].string{
            picture = item
        }
        if let item = json["logo"].string{
            logo = item
        }
    }
}
