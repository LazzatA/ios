//
//  TableViewController.swift
//  UniversityLife
//
//  Created by okokok on 15.02.2024.
//

import UIKit
import Alamofire
import SVProgressHUD
import SwiftyJSON

class TableViewController: UITableViewController {
    
    var arrayUniversity : [UniversityLife] = []
    
    var isLoading: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        //        let university = UniversityLife(name: "test", location: "test", info: "test", picture: "test", logo: "test")
        //        arrayUniversity.append(university)
        //        tableView.reloadData()
        refreshControl = UIRefreshControl()
        refreshControl?.addTarget(self, action: #selector(handleRefresh), for: .valueChanged)
        
        tableView.addSubview(refreshControl!)
        
        loadData()
        
    }
    
    @objc func handleRefresh(){
        if !isLoading{
            isLoading = true
            arrayUniversity.removeAll()
            tableView.reloadData()
            loadData()
        }
    }
        
        
        
        
        func loadData(){
            
            SVProgressHUD.show()
            
            AF.request("https://demo6080262.mockable.io/", method: .get).responseJSON{
                responce in
                
                SVProgressHUD.dismiss()
                
                self.isLoading = false
                self.refreshControl?.endRefreshing()
                
                
                if responce.response?.statusCode == 200 {
                    let json = JSON(responce.value!)
                    print(json)
                    if let resultArray = json.array{
                        for item in resultArray{
                            let universityItem = UniversityLife(json: item)
                            self.arrayUniversity.append(universityItem)
                        }
                        self.tableView.reloadData()
                    }
                }
            }
        }
        
        
        
        // MARK: - Table view data source
        
        override func numberOfSections(in tableView: UITableView) -> Int {
            // #warning Incomplete implementation, return the number of sections
            return 1
        }
        
        override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            // #warning Incomplete implementation, return the number of rows
            return arrayUniversity.count
        }
        
        
        override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! UniTableViewCell
            
            cell.setData(university: arrayUniversity[indexPath.row])
            
            // Configure the cell...
            
            return cell
        }
        
        override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 120
        }
        
       
        
    }

