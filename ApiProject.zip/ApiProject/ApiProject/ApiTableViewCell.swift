//
//  ApiTableViewCell.swift
//  ApiProject
//
//  Created by okokok on 19.02.2024.
//

import UIKit
import SDWebImage

class ApiTableViewCell: UITableViewCell {

    @IBOutlet weak var albomImageView: UIImageView!
    @IBOutlet weak var artistNameLabel: UILabel!
    @IBOutlet weak var songNameLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setData(music: ItunesMusic){
        artistNameLabel.text = music.artistName
        songNameLabel.text = music.trackName
        albomImageView.sd_setImage(with: URL(string: music.artworkUrl100), completed: nil)
        
    }

}
